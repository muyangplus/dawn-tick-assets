晓刻 DawnTick 便携版
渠道 dev · 版本 0.6.12.202611121306

数据与日志都在本目录：dawn-tick.db、dawn-tick.log
整个文件夹拷走即带走全部数据
WebView2 缓存固定在 %LOCALAPPDATA%\com.dawntick.app\EBWebView；窗口几何存在数据库里
设置页「数据」可改存储位置与「启用 WAL 日志模式」
